# blackjack-montecarlo
Monte Carlo solver for blackjack
